<header class="header">
  <a href="./index.php"><svg id="logo-studio" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 234.67 352">
      <defs>
        <style>
          .cls-1 {
            fill: #ccbe9f;
          }
        </style>
      </defs>
      <path class="cls-1" d="M203.21,318.81V75.56a21.83,21.83,0,0,0-10.05-18.38L127.9,15.35a21.2,21.2,0,0,0-23.06.12L41.16,57.24a21.63,21.63,0,0,0-9.77,18.09V339.81h7.83V79.47c-.1-11.42.16-11.9,9.81-18.12l55.9-36.46c11.38-7.56,11.38-7.56,23-.12l57.38,36.58c9.59,6.44,9.93,6.5,10.09,18.4V323c0,8.78.33,8.64-9.76,8.64l-103.14.4V142.19l32-19.36v156.4a4.43,4.43,0,0,0,.81,2.5l3.12,4.34,3-4.27h0a4.42,4.42,0,0,0,.9-2.63V123.09l29.68,19V304.53l7.83,7V137.84l-10.09-6.47V89.72l-31.3-24-32,24,.08,40.92-11.82,7.16V340H194.32C204.67,340,203.21,334.52,203.21,318.81ZM144,127.69l-21.68-13.9V76.21L144,92.42ZM92.14,92.39l22.3-16.25v37.54L92.21,127.14Z" />
    </svg></a>
  <div class="navbar container teal borderYtoX">

    <a class="link" href="./index.php">ACCUEIL</a>
    <a class="link" href="./actu.php">ACTUALITÉ</a>
    <a class="link" href="./contact.php">CONTACT</a>
    <a class="link" href="./charteg.php">PROJET</a>
    <a class="link" href="https://unichamps.sholy.fr" target="_blank">SITE PROJET</a>
  </div>


</header>