<nav class="navbar navbar-expand-lg navbar-dark bg-darkc container-fluid">
	<div class="container-fluid">
		<a class="navbar-brand text-white" href="../index.php"><img src="../imgsrc/logo.png" alt="Logo Unichamps" style=" padding-left: 15px; height: 110px;" /></a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link active text-white" aria-current="page" href="../index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link text-white" href="../actu/actu.php">Actu</a>
				</li>
				<li class="nav-item">
					<a class="nav-link text-white" href="../direct/direct.php">Direct</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active text-white" href="../scoringPoint/scoringPoint.php" tabindex="-1">Classement</a>
				</li>
				<!-- <li class="nav-item">
					<a class="nav-link active text-white" href="/contact/contact.php" tabindex="-1" aria-disabled="true">Contact Us</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active text-white" href="https://discord.gg/6DAZJdRbkk" tabindex="-1" aria-disabled="true" id="contact" target="_blank">Inscrit toi !</a>
				</li> -->
			</ul>
		</div>
	</div>
</nav>